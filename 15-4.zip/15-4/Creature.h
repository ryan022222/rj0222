#ifndef CREATURE_H
#define CREATURE_H
#include<iostream>
#include<cstdlib>

using namespace std;

class Creature
{
public:
    Creature();//constructor
    Creature(int newStrength, int newHitpoints);//constructor

    virtual ~Creature();//destructor

    virtual string getSpecies() const =0;//virtual function
    virtual int getDamage() const ;//virtual function
    

    void setStrength(int newStrength);//set strength
    void setHitpoints(int newHitpoints);// set hitpoints
    
    int getHitpoints() const;//output hitpoints
    int getStrength() const;//output strength

protected:

    int strength;
    int hitpoints;
};

#endif