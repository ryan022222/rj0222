#include "Balrog.h"
#include<string>

using namespace std;

Balrog::Balrog() :Demon()//initialization
{

}
Balrog::Balrog(int newStrength, int newHitpoints) :Demon(newStrength, newHitpoints)//initialization
{

}
string Balrog::getSpecies()const 
{
	return "Balrog";
}