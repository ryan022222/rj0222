#include "Creature.h"
#include<iostream>
#include<ctime>
#include <cstdlib>
using namespace std;

Creature::Creature():strength(10), hitpoints(10)//initialization
{

}
Creature::Creature(int newstrength, int newhitpoints)//initialization
	:strength(newstrength),hitpoints(newhitpoints)
{

}
Creature::~Creature()
{

}
string Creature::getSpecies() const
{
	
	return"";
}
int Creature::getDamage() const
{
	int damage = (rand() % strength) + 1;
	cout << getSpecies() << " attacks for " << damage << " points!" << endl;
	return damage;
}
void Creature::setStrength(int newStrength)
{
	strength = newStrength;
}
void  Creature::setHitpoints(int newHitpoints)
{
	hitpoints = newHitpoints;
}
int  Creature::getHitpoints() const
{
	return hitpoints;

}
int Creature::getStrength() const
{
	return strength;
}