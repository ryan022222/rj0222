#include<ctime>
#include<iostream>
#include<cstdlib>
#include<string>
#include"Creature.h"
#include"Demon.h"
#include"Elf.h"
#include"Cyberdemon.h"
#include"Balrog.h"
#include"Human.h"

using namespace std;

void battleArena(Creature& creature1, Creature& creature2);//output the battle result between two creatures 

int main()
{
	std::srand(static_cast<unsigned int>(std::time(0)));//set random number

    //set strength and hitpoints for each creature.
    Human h(20, 30);
    Elf e(20, 30);
    Cyberdemon c(20, 30);
    Balrog b(20, 30);

    //battle
    cout << "Battle between Human and Elf:" << "\n";
    battleArena(h, e);//output the battle result between Human and Elf.
    //initialization
    h.setStrength(20);
    h.setHitpoints(30);
    e.setStrength(20);
    e.setHitpoints(30);

    cout << "\nBattle between Cyberdemon and Balrog:" << "\n";
    battleArena(c, b);//output the battle result between Cyberdemon and Balrog.
    //initialization
    c.setStrength(20);
    c.setHitpoints(30);
    b.setStrength(20);
    b.setHitpoints(30);

    cout << "\nBattle between Human and Balrog:" << "\n";
    battleArena(h, b);//output the battle result betweenHuman and Balrog.
    //initialization
    h.setStrength(20);
    h.setHitpoints(30);
    b.setStrength(20);
    b.setHitpoints(30);

    system("pause");
    return 0;


}
void battleArena(Creature& creature1, Creature& creature2) {

    //battle will continue until one of the creature has no hitpoint.
    while (creature1.getHitpoints() > 0 && creature2.getHitpoints() > 0)
    {
        int damage1 = creature1.getDamage();//get damage from creature1.
        int damage2 = creature2.getDamage();//get damage from creature2.

        creature1.setHitpoints(creature1.getHitpoints() - damage2);//set new hitpoints after one round of battle.
        creature2.setHitpoints(creature2.getHitpoints() - damage1);//set new hitpoints after one round of battle.

        //output the current hitpoints
        cout << "Creature 1 (" << creature1.getSpecies() << ") has " << creature1.getHitpoints() << " hitpoints left." << endl;
        cout << "Creature 2 (" << creature2.getSpecies() << ") has " << creature2.getHitpoints() << " hitpoints left." << endl;
        if (creature1.getHitpoints()<=0 && creature2.getHitpoints()<=0)
        {
            cout << "This battle is tie."<<"\n";
            break;
        }
        else if (creature1.getHitpoints()>0 && creature2.getHitpoints()<=0)
        {
            cout << creature1.getSpecies() << " wins."<<"\n";
            break;
        }
        else if(creature1.getHitpoints()<=0 && creature2.getHitpoints()>0)
        {
            cout << creature2.getSpecies() << "wins."<<"\n";
            break;

        }



    }

   



}