#include "Elf.h"
#include<string>
#include<ctime>

using namespace std;

Elf::Elf():Creature()//initialization
{

}
Elf::Elf(int thestrength, int thehitpoint) :Creature(thestrength, thehitpoint)//initialization
{

}
string Elf::getSpecies()const 
{
	return"Elf";
}
int  Elf::getDamage() const
{
    int damage=Creature::getDamage();
    if ((rand() % 10) == 0) {
        cout << "Magical attack inflicts " << damage << " additional damage points!" << endl;
        damage *= 2;
    }
    return damage;
}
