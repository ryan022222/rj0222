#ifndef HUMAN_H
#define HUMAN_H
#include "Creature.h"
#include<string>
class Human :public Creature
{
public:
	Human();//constructor
	Human(int thestrength, int thehitpoint);//constructor
	
	string getSpecies() const override ;//output the species
	
private:

};
#endif
