#ifndef CYBERDEMON_H
#define CYBERDEMON_H

#include "Demon.h"
class Cyberdemon :public Demon
{
public:
	Cyberdemon();//constructor
	Cyberdemon(int thestrength, int thehitpoint);//constructor
	string getSpecies() const override;//output the species
	
};

#endif