#ifndef STUDENT_H
#define STUDENT_H
#include<string>
#include"UniversityStaff.h"
using namespace std;


class student
{
public:
	student();
	student(string uni_name, string num, UniversityStaff prof);
	student(const student& other);
		
	void set_uni_name(string thename);
	void set_number(string thenum);
	void set_prof(UniversityStaff theprof);

	string get_uni_name();
	string get_number();
	UniversityStaff get_prof();

	 student& operator=(const student& other) ;
protected:
	string universityname;
	string number;
	UniversityStaff prof;
};
#endif
