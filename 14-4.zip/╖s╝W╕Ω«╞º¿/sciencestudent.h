#ifndef SCIENCESTUDENT_H
#define SCIENCESTUDENT_H
#include "student.h"
class sciencestudent :public student
{
public:
	sciencestudent() ;
	sciencestudent(string uniName, string regNumber, UniversityStaff proctor ,string sciencediscipline, string courseLevel);
	sciencestudent(const sciencestudent& other);
	sciencestudent& operator=(const sciencestudent& right) ;
	void set_sciencediscipline(string thesciencediscipline);
	void set_courseLevel(string thecourseLevel);

	string get_sciencediscipline();
	string get_courseLevel();

	
private:
	string sciencediscipline;
	string courseLevel;
};

#endif