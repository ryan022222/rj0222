#ifndef UNIVERSITYSTAFF
#define UNIVERSITYSTAFF
#include<string>
#include<iostream>

using namespace std;

class UniversityStaff
{
public:
	UniversityStaff();
	UniversityStaff(string theName);
	 
	string getName() const;
	UniversityStaff& operator= (const UniversityStaff& rside); 
	friend istream& operator >>(istream& inStream,UniversityStaff& staffObject);
	friend ostream& operator <<(ostream& outStream, const UniversityStaff& staffobject);
private:
	string name;
	

};
#endif
