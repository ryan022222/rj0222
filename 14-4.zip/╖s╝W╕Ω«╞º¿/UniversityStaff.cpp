#include "UniversityStaff.h"
#include<iostream>
#include<string>

using namespace std;

UniversityStaff::UniversityStaff():name("")
{

}
UniversityStaff::UniversityStaff(string thename):name(thename)
{

}
string UniversityStaff:: getName() const
{
	return name;
}
UniversityStaff& UniversityStaff::operator= (const UniversityStaff& rside)
{
	if (this !=&rside)

		name = rside.name;
	return *this;
}

istream& operator >>(istream& inStream, UniversityStaff& staffObject)
{
	inStream >> staffObject.name;
	return inStream;
 }
ostream& operator <<(ostream& outStream, const UniversityStaff& staffobject)
{
	outStream << staffobject.name;
	return outStream;
}
