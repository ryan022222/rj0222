#include "sciencestudent.h"
#include<string>
#include<iostream>

using namespace std;

sciencestudent::sciencestudent():student(), sciencediscipline(""), courseLevel("")
{

}
sciencestudent::sciencestudent(string uniName, string regNumber, UniversityStaff proctor,string sciencediscipline, string courseLevel)
	:student(uniName, regNumber, proctor), sciencediscipline(sciencediscipline), courseLevel(courseLevel)
{

}
sciencestudent::sciencestudent(const sciencestudent& other)
	:student(other), // �ϥΰ��� Student �������c�y��ƨӪ�l�ư�������
	sciencediscipline(other.sciencediscipline), // ������ǾǬ�
	courseLevel(other.courseLevel) // �����ҵ{����
{


}
sciencestudent& sciencestudent::operator=(const sciencestudent& right) 
{
	if (this!=&right)
	{
		student::operator=(right);
		sciencediscipline = right.sciencediscipline;
		courseLevel = right.courseLevel;

	}
	return *this;
}
void sciencestudent::set_sciencediscipline(string thesciencediscipline)
{
	sciencediscipline = thesciencediscipline;
	
}
void sciencestudent::set_courseLevel(string thecourseLevel)
{
	courseLevel = thecourseLevel;
}
string sciencestudent::get_sciencediscipline()
{
	return sciencediscipline;
}
string sciencestudent::get_courseLevel()
{
	return courseLevel;
}