#include<string>
#include<iostream>
#include "student.h"
#include "UniversityStaff.h"

using namespace std;

student::student() :universityname(""), number(""), prof("")
{


}
student::student(string uni_name, string num, UniversityStaff prof)
	:universityname(uni_name), number(num), prof(prof)
{

}
student::student(const student& other)
	: universityname(other.universityname), number(other.number), prof(other.prof)
{

}
void student::set_uni_name(string uni_name)
{
	universityname = uni_name;
}
void student::set_number(string num)
{
	number = num;
}
void student::set_prof(UniversityStaff Prof)
{
	prof = Prof;

}
string student::get_uni_name()
{
	return universityname;
}
string student::get_number()
{
	return number;
}
UniversityStaff student::get_prof()
{
	return prof;
}

student& student::operator=(const student& other)
{
	if (this != &other) {
		universityname = other.universityname;
		number = other.number;
		prof = other.prof;
	}
	return *this;
}

