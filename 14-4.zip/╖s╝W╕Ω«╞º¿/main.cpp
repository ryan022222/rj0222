#include<iostream>
#include<string>
#include"student.h"
#include"sciencestudent.h"
#include"UniversityStaff.h"

using namespace std;

int main() {

	//TEST class UniversityStaff
	UniversityStaff staff1("sandy"), staff2("eric");
	UniversityStaff staff3("tom");
	cout << "staff1:" << staff1 << "\n";
	cout << "staff2:" << staff2 << "\n";
	cout << "staff3:" << staff3 << "\n";
	//TEST class student
	student std1("v", "123", staff1), std2("d", "456", staff2);
	student std3(std2);
	std1.set_uni_name("m");
	std1.set_number("789");
	std1.set_prof(UniversityStaff(staff1));

	cout << "std1's university name:" << std1.get_uni_name() << "\n";
	cout << "std1's registration Number:" << std1.get_number() << "\n";
	cout << "std1's proctor:" << std1.get_prof() << "\n";


	//TEST class sciencestudent
	sciencestudent sciencestudent1("s", "111", staff3, "physic", "undergratuate");
	sciencestudent sciencestudent2("f", "222", staff3, "physic", "postgratuate");

	sciencestudent sciencestudent3 = sciencestudent2;
	
	cout << "sciencestudent3's sciencediscipline:" << sciencestudent3.get_sciencediscipline() << "\n";
	cout << "sciencestudent3's courselevel:" << sciencestudent3.get_courseLevel() << "\n";

	system("pause");
	return 0;


}
