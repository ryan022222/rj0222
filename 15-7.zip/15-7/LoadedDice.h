#ifndef LOADEDDICE_H
#define LOADEDDICE_H
#include<ctime>
#include<cstdlib>
#include "Dice.h"

using namespace std;

class LoadedDice :public Dice
{
public:
	LoadedDice();//constructor
	LoadedDice(int);//constructor
	int rolldice() const override; //return a nuber between 0 and sides of the dice.
	
};
#endif