#include "LoadedDice.h"
#include<cstdlib>
#include<iostream>

using namespace std;

LoadedDice::LoadedDice() :Dice(6)//constructor
{

}

LoadedDice::LoadedDice(int newsides) :Dice(newsides)//constructor
{

}

int LoadedDice::rolldice() const//return a nuber between 0 and sides of the dice,and have 505 chances return the sides.
{
	if (rand() % 2 == 0)
	{
		return sides;
	}
	else
	{
		return Dice::rolldice();
	}
}