#include "Dice.h"
#include<cstdlib>
#include<iostream>

using namespace std;

Dice::Dice():sides(6)//constructor
{
	srand(time(NULL));
}
Dice::Dice(int thesides):sides(thesides)//constructor
{
	srand(time(NULL));
}
void Dice::setsides(int thesides)//set sides of dice.
{
	sides = thesides;
}
int Dice::getsides()//return sides of dice.
{
	return sides;
}

int Dice::rolldice() const//virtual function that return a nuber between 0 and sides of the dice.
{
	return (rand() % sides)+1;
}

