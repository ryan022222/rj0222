#ifndef DICE_H
#define DICE_H
class Dice
{
public:
	Dice();//constructor
	Dice(int sides);//constructor
	virtual int rolldice() const;//virtual function that return a nuber between 0 and sides of the dice.
	void setsides(int);//set sides of dice.
	int getsides();//return sides of dice.
protected:
	int sides;

};

#endif