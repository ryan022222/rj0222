#include"Dice.h"
#include"LoadedDice.h"
#include<cstdlib>
#include<iostream>
#include<ctime>
using namespace std;

int rolltwodice(Dice& dice1, Dice& dice2);//return the sum of two dices.

int main() {
	
	Dice d1(6);//set object of dice.
	Dice d2(6);//set object of dice.
	for (int i = 0; i < 10; i++)//iterate for ten times.
	{
		int sum1=rolltwodice(d1, d2);
		cout <<"Result of Dice" << i + 1 <<":" << sum1 << "\n";//output each sum in each time the fuction run.

	}
	cout<<"\n";

	LoadedDice d3(14);//set object of LoadedDice.
	LoadedDice d4(16);//set object of LoadedDice.
	for (int i = 0; i < 10; i++)//iterate for ten times.
	{
		int sum2 = rolltwodice(d3, d4);
		cout << "Result of LoadeDice" << i + 1 << ":" << sum2 << "\n";//output each sum in each time the fuction run.

	}

	system("pause");
	return 0;




}
int rolltwodice(Dice& dice1, Dice& dice2)//return the result of dice1 plus dice2.
{
	return (dice1.rolldice() + dice2.rolldice());
}