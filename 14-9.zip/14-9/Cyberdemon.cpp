#include "Cyberdemon.h"
#include<string>

using namespace std;

Cyberdemon::Cyberdemon():Demon()//initialization
{

}
Cyberdemon::Cyberdemon(int newStrength, int newHitpoints) : Demon(newStrength, newHitpoints) //initialization
{

}
string Cyberdemon::getSpecies() const 
{
	return"Cyberdemon";
}
