#ifndef BALROG_H
#define BALROG_H

#include "Demon.h"
class Balrog :public Demon
{
public:
	Balrog();//constructor
	Balrog(int thestrength, int thehitpoint);//consturctor
	string getSpecies()const  override;//output the species

};

#endif