#ifndef ELF_H
#define ELF_H
#include "Creature.h"
class Elf : public Creature
{
public:
	Elf();//constructor
	Elf(int thestrength, int thehitpoint);//constructor
	string getSpecies() const override;//output the species
	
	int getDamage() const;//output damage
};

#endif