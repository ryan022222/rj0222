#include "Demon.h"
#include<ctime>
#include<string>

using namespace std;

Demon::Demon():Creature()//initialization
{

}
Demon::Demon(int thestrength, int thehitpoint) :Creature(thestrength, thehitpoint)//initialization
{

}

int Demon::getDamage() const 
{
    int damage = Creature::getDamage();
    if ((rand() % 100) < 5) {
        damage += 50;
        cout << "Demon attack inflicts 50 additional damage points!" << "\n";
    }
    return damage;

}