#include "Human.h"
#include<ctime>
#include<iostream>
#include<string>

using namespace std;

Human::Human():Creature()//initialization
{

}
Human::Human(int thestrength, int thehitpoint)//initialization
	:Creature(thestrength,thehitpoint)
{

}

string  Human::getSpecies() const
{
	return"Human";
}
