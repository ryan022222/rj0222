#include<ctime>
#include<iostream>
#include<cstdlib>
#include<string>
#include"Creature.h"
#include"Demon.h"
#include"Elf.h"
#include"Cyberdemon.h"
#include"Balrog.h"
#include"Human.h"

using namespace std;


int main()
{


    //set strength and hitpoints for each creature.
    Human h(20, 30);
    Elf e(20, 30);
    Cyberdemon c(20, 30);
    Balrog b(20, 30);

    cout << h.getSpecies() << "--Strength:" << h.getStrength() << " hitpoints:" << h.getHitpoints() << "\n";
    cout << e.getSpecies() << "--Strength:" << e.getStrength() << " hitpoints:" << e.getHitpoints() << "\n";
    cout << c.getSpecies() << "--Strength:" << c.getStrength() << " hitpoints:" << c.getHitpoints() << "\n";
    cout << b.getSpecies() << "--Strength:" << b.getStrength() << " hitpoints:" << b.getHitpoints() << "\n";
    system("pause");
    return 0;


}
