#ifndef DEMON_H
#define DEMON_H
#include "Creature.h"
#include<string>

using namespace std;

class Demon :public Creature
{
public:
	Demon();//constructor
	Demon(int newstrength, int hitpoints);//constructor
	
	int getDamage()  const override;//output the species
	
};

#endif