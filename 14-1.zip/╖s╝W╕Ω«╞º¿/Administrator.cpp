#include<iostream>
#include<string>

#include"Administrator.h"
using std::string;
using std::cout;
using std::cin;

namespace SavitchEmployees

{
	Administrator::Administrator() :SalariedEmployee(),title(""), area(""), supervisor("")
	{

	}
	Administrator::Administrator(string theName, string theSSN, double theSalary, string theTitle, string theArea, string theSupervisor)
		: SalariedEmployee(theName, theSSN, theSalary), title(theTitle), area(theArea), supervisor(theSupervisor)
	{

	}

	
	void Administrator::setsupervisor(string& supervisername)
	{
		supervisor = supervisername;

	}

	void Administrator::settitle(string& newtitle)
	{
		title = newtitle;
	}

	void Administrator::setarea(string& newarea)
	{
		area = newarea;
	}
void  Administrator::getdata()
	{
		cout << "Enter the title of the employee" << "\n";
		cin >> title;
		cout<<"Enter area of responsibility"<< "\n";
		cin >> area;
		cout<<"Enter the supervisor " << "\n";
		cin >> supervisor;
	}

	void Administrator::print()
	{
		cout << "Title: " << title << "\n";
		cout << "Area of Responsibility: " << area << "\n";
		cout << "Supervisor: " << supervisor << "\n";
	}
	void Administrator::printcheck()
	{
		
		cout << "Salary:" << salary << "\n";

	}
}














