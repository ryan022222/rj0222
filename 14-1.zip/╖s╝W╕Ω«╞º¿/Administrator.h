#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H

#include<iostream>
#include<string>
#include"salariedemployee.h"

using std::string;

namespace SavitchEmployees

{
	class Administrator:public SalariedEmployee
	{
	public:
		Administrator();
		Administrator(string theName, string theSSN, double theSalary, string theTitle, string theArea, string theSupervisor);
			

		void setsupervisor(string &bossname);
		void settitle(string& newtitle);
		void setarea(string& newarea);

		void getdata();
		void print();
		void printcheck();


	private:
		string title;
		string area;
		string supervisor;




	};


}










#endif