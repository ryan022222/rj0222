#include<iostream>
#include<string>

#include"Administrator.h"

using std::cout;
using std::string;

using SavitchEmployees::SalariedEmployee;
using SavitchEmployees::Administrator;
	int main()
	{
		Administrator adm;
		adm.setName("Joe");
		adm.setSalary(20);
		adm.getdata();
		adm.print();
		adm.printcheck();
		system("pause");
		return 0;
	}
